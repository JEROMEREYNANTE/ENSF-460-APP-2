/* 
 * File:   IOs.h
 * Author: Jerome Reynante
 *
 * Created on November 3, 2023, 6:08 PM
 */

#ifndef IOS_H
#define	IOS_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

void NewClk(unsigned int clkval);  

#endif	/* IOS_H */

